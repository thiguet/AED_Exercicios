package Model;

public interface IDemandaExercicio {
	public void orderByMyOrdenation();
	public void orderByRandom();
}
