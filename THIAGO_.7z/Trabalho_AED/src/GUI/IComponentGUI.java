package GUI;

public interface IComponentGUI {
	void initializeGUI();
	void initializeComponent();
}
